attribute vec3 aRoot;
attribute float aTip;
attribute float aRand;
varying float vTip;
varying float vRand;
//#main
float gust = sin(uTime * 1.4 + aRoot.x * .22 + aRoot.z * .15) * .5 + .5;
float flick = sin(uTime * 3.1 + aRand * 20. + aRoot.x) * .15;
vec2 wind = uWindDir * (gust * .45 + flick);

// bend away from the car
vec2 away = aRoot.xz - uCarPos.xz;
float dd = length(away);
float push = (1. - smoothstep(0.7, 2.8, dd)) * step(uCarPos.y, aRoot.y + 3.5);
float bh = position.y - aRoot.y;
transformed.xz += wind * bh + normalize(away + 1e-4) * push * bh * 1.1;
transformed.y -= push * bh * .55;

vTip = aTip;
vRand = aRand;
