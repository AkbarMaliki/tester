// Wallet: the player's money (G). Pure data + events, no DOM: shops, shipping bins, quests… call addGold / spendGold,
// the HUD (ui/inventory.js) listens to wallet:changed.
import { emit } from '../engine/events.js';
import { START_GOLD } from '../game/config.js';
import { registerSave } from './save.js';

export const wallet = { gold: START_GOLD };

const changed = (delta) => emit('wallet:changed', { gold: wallet.gold, delta });
export const canAfford = (n) => wallet.gold >= n;
export function addGold(n) {
  n = Math.round(n);
  if (!n) return;
  wallet.gold = Math.max(0, wallet.gold + n);
  changed(n);
}
// pays n if there's enough; returns false and changes nothing otherwise
export function spendGold(n) {
  n = Math.round(n);
  if (wallet.gold < n) return false;
  wallet.gold -= n;
  changed(-n);
  return true;
}
export const fmtGold = (n) => `${Math.round(n).toLocaleString('id-ID')} G`;

registerSave('wallet', {
  save: () => wallet.gold,
  load(d) { wallet.gold = Math.max(0, Math.round(+d || 0)); changed(0); },
  reset() { wallet.gold = START_GOLD; changed(0); },
  summary: (d) => fmtGold(d),
});
